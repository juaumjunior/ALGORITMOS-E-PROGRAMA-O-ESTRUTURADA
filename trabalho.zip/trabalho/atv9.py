c = float(input("informe sua temperatura em celsius: "))
k = c + 273.15
print("sua temperatura em kelvin é: ", k)