n1 = 5.7
quad = n1 * n1
print(f"o quadrado de {n1} é igual á {quad}")