k = int(input("informe sua velocidade em km/h: "))
m = k / 3.6
print("sua velocidade em m/s é equivalente há: ", m)