raio = float(input("informe o raio do circulo: "))
pi = 3.141592
area = pi * (raio * raio)
print("a area do circulo é igual há: ", area)