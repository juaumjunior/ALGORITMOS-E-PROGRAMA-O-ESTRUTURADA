custof = float(input("informe o valor de custo da fábrica: "))
custod = 0.12
custoi = 0.45
valor = custof * (1 + custod + custoi)

print("o valor a ser pago é: ", valor)
