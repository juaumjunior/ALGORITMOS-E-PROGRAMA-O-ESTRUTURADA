salario = float(input("informe seu salario: "))
aument = salario * 0.0177
vlrsal = aument + salario 
print("o salario com o aumento é: ", vlrsal)