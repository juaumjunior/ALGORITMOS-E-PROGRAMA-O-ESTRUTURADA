c = float(input("informe sua temperatura em Celsius: "))
f = 9/5 * c + 32
print("sua temperatura em farenheit é: ", f)