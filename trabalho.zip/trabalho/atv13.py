k = float(input("informe a distancia percorrida em quilometros: "))
m = k / 1.61
print("a distancia percorrida em milhas é: ", m) 