vlrhr = float(input("informe o quanto você recebe por hora: "))
hr = float(input("informe quantas horas você trabalhou no mês: "))
totalhr = vlrhr * hr
acrecimo = totalhr * 0.10
totalacre = totalhr + acrecimo
print("seu salario no final do mês foi: ", totalacre)