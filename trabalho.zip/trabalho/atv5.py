n1 = 50.46
qui = n1 / 5
print(f"a quinta parte de {n1} é igual a {qui}")