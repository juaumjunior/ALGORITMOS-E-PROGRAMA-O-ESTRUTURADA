n = 56
print("o numero real é: ", n)