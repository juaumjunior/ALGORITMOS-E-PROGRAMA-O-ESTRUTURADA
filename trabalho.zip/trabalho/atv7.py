f = float(input("informe sua temperatura em farenheit: "))
c = 5 * (f - 32) / 9
print("sua temperatura em Celsius é: ", c)