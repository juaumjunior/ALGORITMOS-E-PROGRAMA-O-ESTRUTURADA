vlr = 780000.00
vlr1 = vlr * 0.46
vlr2 = vlr * 0.36
vlr3 = vlr - vlr1 - vlr2
print(f"o primeiro ganhados vai ganhar {vlr1} o segundo {vlr2} e o terceiro {vlr3}")