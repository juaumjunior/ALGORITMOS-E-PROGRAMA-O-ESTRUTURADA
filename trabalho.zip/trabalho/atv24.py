import math
a = float(input("Digite o valor do cateto a: "))
b = float(input("Digite o valor do cateto b: "))
hipotenusa = math.sqrt(a**2 + b**2)
print("A hipotenusa é:", hipotenusa)
