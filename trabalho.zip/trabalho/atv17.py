print("informe quatro números: ")
n1 = int(input("primeiro numero: "))
n2 = int(input("segundo numero: "))
n3 = int(input("terceiro numero: "))
n4 = int(input("quarto numero: "))
media = (n1 + n2 + n3 + n4) / 4
print("a media aritmetica dos numeros digitado acima é igual a: ", media)