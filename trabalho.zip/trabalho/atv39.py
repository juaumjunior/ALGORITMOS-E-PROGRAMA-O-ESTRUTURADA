idade = int(input("Digite sua idade: "))
anoatual = int(input("Digite o ano atual: "))
anonascimento = anoatual - idade
print(f"Seu ano de nascimento é: {anonascimento}")
