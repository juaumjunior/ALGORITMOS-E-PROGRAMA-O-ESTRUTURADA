letramaiuscula = input("Digite uma letra maiúscula: ")
letraminuscula = chr(ord(letramaiuscula) + 32)
print(f"A letra minúscula correspondente é: {letraminuscula}")
