k = float(input("informe sua temperatura em Kelvin: "))
c = k - 273.15
print("sua temperatura em celsius é: ", c)