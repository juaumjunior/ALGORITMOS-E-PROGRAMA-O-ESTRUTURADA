x = int(input("informe um numero inteiro: "))
suc = x * 3 + 1
ant = x * 2 -1
print(f"o sucessor do triplo do numero digitado é {suc} e o antecessor de seu dobro é {ant}")