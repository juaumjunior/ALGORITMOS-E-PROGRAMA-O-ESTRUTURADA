
vr = float(input("Digite o valor em reais: "))
cdr = float(input("Digite a cotação do dólar: "))
vd = vr / cdr
print("O valor em dólares é: ", vd)