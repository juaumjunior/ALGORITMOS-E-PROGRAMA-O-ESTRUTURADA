m = int(input("informe sua velocidade em m/s: "))
k = m * 3.6
print("sua velocidade em km/h é equivalente há: ", k)