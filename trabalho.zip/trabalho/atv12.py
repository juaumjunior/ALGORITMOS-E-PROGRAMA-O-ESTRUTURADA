m = float(input("informe a distancia percorrida em milhas aéreas: "))
k = m * 1.61
print("a distancia percorrida em km é: ", k) 