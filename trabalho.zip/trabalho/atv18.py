g1 = float(input("informe a nota G1: "))
g2 = float(input("informe a nota G2: "))
media = (g1 + (g2 * 2)) / 3
print("sua media foi: ", media )
if media >= 7.0:
    print("aprovado")
else:
    print("reprovado")
    