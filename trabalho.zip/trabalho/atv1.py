##Faça um programa que leia um número inteiro e o imprima.
n = -56
print("o numero inteiro é: ", n)