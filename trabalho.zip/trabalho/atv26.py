vlrprt = float(input("informe o valor do produto: "))
desc = vlrprt * 0.12
vlrdesc = vlrprt - desc 
print("o valor do produto com o desconto é: ", vlrdesc)