n1 = float(input("informe a nota da prova 1: "))
m = 7
n2 = ((m * 3) - n1) / 2
print(f"você precisa tirar {n2} para atingir a média")