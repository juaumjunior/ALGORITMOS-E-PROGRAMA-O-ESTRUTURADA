l = float(input("informe a largura: "))
c = float(input("informe o comprimento: "))
p = float(input("informe a profundidade: "))
v = l * c * p 
print("o volume é: ", v)