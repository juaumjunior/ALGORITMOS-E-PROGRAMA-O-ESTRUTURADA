np = float(input("informe a nota da prova: "))
nq = float(input("informe a nota qualitativa: "))
media = nq + (np * 2) / 3

print("sua média é: ", media)