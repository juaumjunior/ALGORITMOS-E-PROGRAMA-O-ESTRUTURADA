n = int(input("informe um numero inteiro: "))
ant = n - 1
suc = n + 1 
print(f"o antecessor do número digitado é {ant} e seu sucessor é {suc}")