valortotal = float(input("informe o valor total da venda: "))
desc  = valortotal * 0.10
vlrdesc = valortotal - desc
print("o valor com 10 porcento de desconto é: ", vlrdesc)
parc = valortotal / 3 
print("o valor cem 3x sem juros é igual há: ", parc)
com1 = vlrdesc * 0.05
print("o valor da comissão do vendedor referente a venda com desconto é: ", com1)
com2 = valortotal * 0.05
print("o valor da comissão do vendedor referente a venda parcelada é: ", com2)