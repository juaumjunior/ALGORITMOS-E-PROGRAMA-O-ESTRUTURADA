print("informe três valores e descubra a soma deles: ")
n1 = int(input("primeiro valor: "))
n2 = int(input("segundo valor: "))
n3 = int(input("terceiro valor: "))
soma = n1 + n2 + n3
print("a soma dos valores é ", soma)