import math
ad = float(input("Digite a altura do degrau da escada em metros: "))
ade = float(input("Digite a altura que você deseja alcançar em metros: "))
nd = (ade / ad)
print(f"Você precisa subir {nd} degraus para alcançar a altura desejada.")