g = float(input("informe o grau que deseja conhecer seu radiano: "))
p = 3.14
r = g * p / 180
print("resultado convertido em radiano:", r)