qh = float(input("informe a quantidade de hamburguer: "))
qc = float(input("informe a quantidade de cheeseburger: "))
qf = float(input("informe a quantidade de fritas: "))
qr = float(input("informe a quantidade de refrigerante: "))
qm = float(input("informe a quantidade de milkshake: "))

tqh = qh * 3.0 
tqc = qc * 2.5
tqf = qf * 2.5
tqr = qr * 1.00
tqm = qm * 3.0

print (f"""quantidade de hamburguer: {tqh}
quantidade de cheeseburger: {tqc}
quantidade de fritas: {tqf}
quantidade de refrigerante: {tqr}
quantidade de milkshake: {tqm} """)