raio = float(input("informe o raio do cilindro: "))
h = float(input("informe a altura do clilindro"))
pi = 3.141592
v = pi * (raio * raio) * h
print("o volume do cilindro é: ", v)
