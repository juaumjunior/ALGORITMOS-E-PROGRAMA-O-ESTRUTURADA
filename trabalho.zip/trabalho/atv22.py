lado = float(input("informe o lado do quadrado: "))
area = lado * lado 
print(" a area do quadrado é", area)